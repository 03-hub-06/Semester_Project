#include <iostream>
#include <string>
using namespace std;

int main() {
    string name;
    cout << "Welcome to the Adventure Game!" << endl;
    cout << "What is your name?" << endl;
    getline(cin, name);
    cout << "Hello, " << name << "! Let's begin our adventure." << endl;

    string choice1;
    cout << "You are in a forest. Do you want to go left or right?" << endl;
    getline(cin, choice1);
    if (choice1 == "left") {
        cout << "You have encountered a dragon! Do you want to fight or run away?" << endl;
        string choice2;
        getline(cin, choice2);
        if (choice2 == "fight") {
            cout << "You have defeated the dragon and found treasure!" << endl;
            cout << "Do you want to take the treasure or leave it?" << endl;
            string choice3;
            getline(cin, choice3);
            if (choice3 == "take") {
                cout << "You have taken the treasure and become rich!" << endl;
            } else {
                cout << "You have left the treasure and continued on your adventure." << endl;
            }
        } else {
            cout << "You have escaped the dragon but missed the treasure." << endl;
        }
    } else {
        cout << "You have found a peaceful meadow and enjoyed a nice picnic." << endl;
        cout << "Do you want to explore the meadow or rest?" << endl;
        string choice4;
        getline(cin, choice4);
        if (choice4 == "explore") {
            cout << "You have discovered a hidden cave with ancient artifacts!" << endl;
        } else {
            cout << "You have rested and regained your strength for the next adventure." << endl;
        }
    }

    cout << "Thank you for playing the Adventure Game!" << endl;
    return 0;
}

